from flask import Flask, render_template, request
from transformers import pipeline

app = Flask(__name__)
summarizer = pipeline("summarization")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/submit_course", methods=["POST"])
def submit_course():
    content = request.form["course_text"]
    try:
        summary = summarizer(content, max_length=150, min_length=40, do_sample=False)[0]["summary_text"]
        return render_template("result.html", summary=summary)
    except Exception as e:
        return f"Erreur lors du résumé : {e}"

@app.route("/generate_qcm", methods=["POST"])
def generate_qcm():
    fake_qcm = """
    Question : Quelle est la capitale de la France ?
    A) Madrid
    B) Rome
    C) Paris
    D) Berlin

    Réponse correcte : C) Paris
    Explication : Paris est la capitale de la France.
    """
    return render_template("qcm.html", qcm=fake_qcm)

if __name__ == "__main__":
    app.run(debug=True)
